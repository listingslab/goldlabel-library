'use client';
import * as React from 'react';
import {
  Box,
  CardActions,
  TextField,
  IconButton,
  Typography,
} from '@mui/material';
import IconSettings from '@mui/icons-material/AccountBalance';

export default function Signup() {
  const validateEmail = (email: string) => {
    let isValid: boolean = true;
    if (email === '') {
      isValid = false;
    }
    return isValid;
  };

  return (
    <>
      <Box id="goldlabel-auth-signin">
        <Box sx={{ mx: 2 }}>
          <Typography variant="button" component="h3">
            Sign In
          </Typography>
        </Box>
        <Box sx={{ mx: 2, mb: 1 }}>
          <TextField
            fullWidth
            variant="standard"
            id="goldlabel-auth-signin-email"
            autoCapitalize="none"
            label="Email"
            onChange={(e) => {
              e.preventDefault();
              validateEmail(e.target.value);
            }}
          />
        </Box>

        <CardActions>
          <Box sx={{ mx: 1 }}>
            <IconButton
              id="goldlabel-auth-signin-btn"
              color="inherit"
              onClick={(e: React.MouseEvent) => {
                e.preventDefault();
                console.log('Dispatch sign in action');
              }}
            >
              <IconSettings />
            </IconButton>
          </Box>
        </CardActions>
      </Box>
    </>
  );
}
