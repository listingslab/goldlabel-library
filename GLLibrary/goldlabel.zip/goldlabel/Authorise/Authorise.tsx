'use client';
import * as React from 'react';
import { Signin } from './';
import {
  useGoldlabelSelect,
  useGoldlabelDispatch,
  selectAuthorising,
  selectUser,
  firebaseSignout,
} from '../AppState';
import { Box, CircularProgress, Typography, Button } from '@mui/material';

export default function Authorise(props: any) {
  const { children } = props;
  const dispatch = useGoldlabelDispatch();
  const user = useGoldlabelSelect(selectUser);
  const authorising = useGoldlabelSelect(selectAuthorising);

  if (user) {
    return (
      <>
        {children}
        <Button
          onClick={() => {
            dispatch(firebaseSignout());
          }}
          variant="outlined"
        >
          Sign out
        </Button>
      </>
    );
  }
  if (!authorising) {
    return (
      <>
        <Typography gutterBottom variant="h6" component="h1" color="primary">
          You
        </Typography>
        <Box sx={{ mt: 2 }}>
          <Signin />
        </Box>
      </>
    );
  }
  return <CircularProgress sx={{ m: 1 }} />;
}
