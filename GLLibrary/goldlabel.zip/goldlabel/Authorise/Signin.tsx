'use client';
import * as React from 'react';
import {
  ButtonBase,
  Box,
  CardActions,
  TextField,
  Typography,
} from '@mui/material';
import {
  useGoldlabelSelect,
  useGoldlabelDispatch,
  selectSigninForm,
  updateSignin,
  firebaseSignin,
} from '../AppState';
import IconSignin from '@mui/icons-material/ExitToAppOutlined';

export default function Signin() {
  const dispatch = useGoldlabelDispatch();
  const signinForm = useGoldlabelSelect(selectSigninForm);

  const onUpdateInput = (key: string, value: any) => {
    dispatch(updateSignin(key, value));
  };

  const { email, password } = signinForm;

  return (
    <>
      <Box id="goldlabel-auth-signin">
        <Box sx={{ mb: 2, mt: 1, maxWidth: 300 }}>
          <TextField
            id="goldlabel-signin-email"
            autoFocus
            fullWidth
            value={email.value}
            // error={!email.valid}
            variant="outlined"
            color="primary"
            autoCapitalize="none"
            label="Email"
            onChange={(e) => {
              e.preventDefault();
              onUpdateInput('email', e.target.value);
            }}
          />
        </Box>

        <Box sx={{ mb: 2, maxWidth: 300 }}>
          <TextField
            id="goldlabel-signin-password"
            value={password.value}
            // error={!password.valid}
            variant="outlined"
            color="primary"
            autoCapitalize="none"
            fullWidth
            label="Password"
            type="password"
            onChange={(e) => {
              e.preventDefault();
              onUpdateInput('password', e.target.value);
            }}
          />
        </Box>

        <CardActions>
          <Box sx={{ display: 'flex' }}>
            <ButtonBase
              id="goldlabel-signin-btn"
              sx={{ borderRadius: 1 }}
              onClick={(e: React.MouseEvent) => {
                e.preventDefault();
                dispatch(firebaseSignin());
              }}
            >
              <Box sx={{ mr: 1, mt: -0.5 }}>
                <Typography>Sign in</Typography>
              </Box>
              <Box sx={{ ml: 1 }}>
                <IconSignin color="primary" />
              </Box>
            </ButtonBase>
          </Box>
        </CardActions>
      </Box>
    </>
  );
}
