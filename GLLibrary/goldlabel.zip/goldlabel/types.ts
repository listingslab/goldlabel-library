export interface ContentShape {
  title: string;
  description: string;
  path: string;
  img?: ImgShape;
}

export interface ImgShape {
  src: string;
  alt: string;
  caption?: string;
}

export interface GoldlabelState {
  vs?: string;
  content: ContentShape | null;
  user?: {
    uid: string;
    role: string;
    email: string;
  } | null;
  authorising: boolean;
  notification: Notification | null;
  signinForm: {
    email: {
      value: string;
      valid: boolean;
    };
    password: {
      value: string;
      valid: boolean;
    };
  };
  navDialogOpen?: boolean;
}

export type KeyValueShape = {
  key: string;
  value: any;
};

export type Notification = {
  code: string;
  severity: 'success' | 'info' | 'warning' | 'error' | undefined;
  message: string;
};

export type Error = {
  time: number;
  severity: string;
  code: string;
  message: string;
  stack: any;
};
