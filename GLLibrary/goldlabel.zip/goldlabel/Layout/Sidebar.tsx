import * as React from 'react';
import { Box, Grid } from '@mui/material';
import { FixedNav } from '../Nav';
// import { CallToAction } from '../Layout';

export default function Sidebar() {
  return (
    <Box id="goldlabel-sidebar">
      <FixedNav />
    </Box>
  );
}

/* <Grid container spacing={1}>
        <Grid item sm={6} md={12}>
          <CallToAction
            severity="success"
            path="/wip/openai"
            title="Artificially Intelligent"
          />
        </Grid>
        <Grid item sm={6} md={12}>
          <CallToAction
            severity="error"
            path="/wip/"
            title="Work In Progress"
          />
        </Grid>
      </Grid> */
