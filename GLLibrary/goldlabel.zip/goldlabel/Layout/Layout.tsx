import React from 'react';
import {
  CssBaseline,
  ThemeProvider,
  Container,
  Box,
  Grid,
  Typography,
} from '@mui/material';
import { muiTheme, NextImage } from '../Design';
import { DialogNav } from '../Nav';
import { Sidebar, Notify, Header } from '../Layout';
import { useGoldlabelSelect, selectContent } from '../AppState';
export default function Layout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const content = useGoldlabelSelect(selectContent);
  if (!content) return null;

  let img: any = null;
  if (content.img) img = content.img;

  return (
    <Box id="goldlabel-layout">
      <ThemeProvider theme={muiTheme}>
        <CssBaseline />
        <DialogNav />
        <Notify />
        <Container maxWidth="md">
          <Box
            sx={{
              minHeight: 'calc(100vh - 40px)',
            }}
          >
            <Header />
            <Grid container spacing={1}>
              <Grid item xs={12}>
                {img ? (
                  <NextImage src={img.src} alt={img.alt} height={250} />
                ) : null}
              </Grid>

              <Grid item xs={12} sm={4}>
                <Box sx={{ display: { xs: 'none', sm: 'block' } }}>
                  <Sidebar />
                </Box>
              </Grid>

              <Grid item xs={12} sm={8}>
                <Box
                  id="goldlabel-main"
                  sx={{
                    mt: 2,
                  }}
                >
                  {children}
                </Box>
              </Grid>
            </Grid>
          </Box>

          <Box
            id="goldlabel-footer"
            component={'footer'}
            sx={{ textAlign: 'center', mb: 3 }}
          >
            <Typography variant="caption">@2025 Goldlabel Apps Ltd</Typography>
          </Box>
        </Container>
      </ThemeProvider>
    </Box>
  );
}

/* <NextImage height={300} alt={imgAlt} src={imgSrc} /> 
<pre>{JSON.stringify(content, null, 2)}</pre>
*/
