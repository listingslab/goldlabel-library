import * as React from 'react';
import { Box, ButtonBase, Alert, Typography } from '@mui/material';
import { useGoldlabelDispatch, navigateTo } from '../AppState';

export default function CallToAction(props: any) {
  const { title, path, severity } = props;
  const dispatch = useGoldlabelDispatch();
  return (
    <ButtonBase
      onClick={() => {
        dispatch(navigateTo(path, '_self'));
        console.log('CallToAction clicked', path);
      }}
      sx={{
        // my: 0.5,
        display: 'block',
        width: '100%',
      }}
    >
      <Alert severity={severity} variant="outlined">
        <Box
          sx={{
            mt: -0.75,
          }}
        >
          <Typography variant="h6">{title}</Typography>
        </Box>
      </Alert>
    </ButtonBase>
  );
}
