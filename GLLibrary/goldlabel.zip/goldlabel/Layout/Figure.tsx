import { Box, Skeleton, Stack } from '@mui/material';

export default function Figure() {
  return (
    <figure>
      <Skeleton variant="rectangular" width={'100%'} height={225} />
    </figure>
  );
}
