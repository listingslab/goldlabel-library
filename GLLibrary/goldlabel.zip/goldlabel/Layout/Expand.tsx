import * as React from 'react';
import { Accordion, AccordionSummary, AccordionDetails } from '@mui/material';
import IconExpand from '@mui/icons-material/ArrowDownwardOutlined';

export default function Expand(props: any) {
  const { title, content, defaultExpanded } = props;
  return (
    <Accordion defaultExpanded={defaultExpanded} sx={{ boxShadow: 'none' }}>
      <AccordionSummary expandIcon={<IconExpand color="primary" />}>
        {title}
      </AccordionSummary>
      <AccordionDetails>{content}</AccordionDetails>
    </Accordion>
  );
}
