import * as React from 'react';
import { useGoldlabelSelect, selectNotification } from '../AppState';

export default function Notify() {
  const notification = useGoldlabelSelect(selectNotification);
  if (!notification) return null;

  return (
    <>
      <pre style={{ fontSize: 10 }}>
        notification: {JSON.stringify(notification, null, 2)}
      </pre>
    </>
  );
}
