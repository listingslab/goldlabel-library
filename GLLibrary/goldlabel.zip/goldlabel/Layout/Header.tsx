import * as React from 'react';
import { Avatar, Box, CardHeader, IconButton } from '@mui/material';
import {
  useGoldlabelDispatch,
  useGoldlabelSelect,
  selectNavDialogOpen,
  toggleNavDialogOpen,
  navigateTo,
  selectContent,
} from '../AppState';
import { Icon } from '../Design';

export default function Header() {
  const navDialogOpen = useGoldlabelSelect(selectNavDialogOpen);
  const dispatch = useGoldlabelDispatch();
  const content = useGoldlabelSelect(selectContent);

  React.useEffect(() => {
    // console.log("navDialogOpen", navDialogOpen )
  }, [navDialogOpen]);
  if (!content) return null;
  const { title, description } = content;
  return (
    <Box id="goldlabel-header">
      <CardHeader
        title={title}
        subheader={description}
        avatar={
          <Box sx={{}}>
            <IconButton
              sx={{ ml: -2 }}
              color="inherit"
              onClick={(e: React.MouseEvent) => {
                e.preventDefault();
                dispatch(navigateTo('/', '_self'));
              }}
            >
              <Avatar src="/png/icons/icon-96x96.png" />
            </IconButton>
          </Box>
        }
        action={
          <Box sx={{ display: { xs: 'block', sm: 'none' } }}>
            <IconButton
              sx={{ mr: -2 }}
              color="inherit"
              onClick={(e: React.MouseEvent) => {
                e.preventDefault();
                dispatch(toggleNavDialogOpen(!navDialogOpen));
              }}
            >
              <Icon icon="menu" color="primary" />
            </IconButton>
          </Box>
        }
      />
    </Box>
  );
}
