import * as React from 'react';
import Image from 'next/image';
import { Box } from '@mui/material';

export default function NetImage(props: any) {
  const { src, alt, height } = props;
  return (
    <Box
      sx={{
        position: 'relative',
        width: '100%',
        height,
      }}
    >
      <Image
        fill
        priority
        sizes="xl"
        style={{ objectFit: 'cover' }}
        src={src}
        alt={alt}
      />
    </Box>
  );
}
