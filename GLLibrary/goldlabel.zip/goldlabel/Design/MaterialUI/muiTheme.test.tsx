import muiTheme from './muiTheme';

describe('Theme', () => {
  it('should be defined', () => {
    expect(muiTheme).toBeDefined();
  });

  it('Should have a palette with primary and secondary colors', () => {
    expect(muiTheme.palette).toBeDefined();
    expect(muiTheme.palette.primary).toBeDefined();
    expect(muiTheme.palette.secondary).toBeDefined();
    expect(muiTheme.palette.error).toBeDefined();
  });

  it('Should have the correct primary color', () => {
    expect(muiTheme.palette.primary.main).toBe('#c09f52');
  });

  it('Should have the correct secondary color', () => {
    expect(muiTheme.palette.secondary.main).toBe('#937f50');
  });
});
