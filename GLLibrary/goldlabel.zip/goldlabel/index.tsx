import Goldlabel from './Goldlabel';
import Start from './Start';
export { Goldlabel, Start };
