'use client';
import * as React from 'react';
import { Provider } from 'react-redux';
import { store } from './AppState';
import { Start } from './';

export default function Goldlabel(props: {
  children: React.ReactNode;
  content: any;
}) {
  const { children, content } = props;
  return (
    <Provider store={store}>
      <Start content={content}>{children}</Start>
    </Provider>
  );
}
