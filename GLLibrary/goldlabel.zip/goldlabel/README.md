## Goldlabel NextJS

Start. Every app needs an entry point. Somewhere to set up the initial variables and kick things off. Why not put this in the Goldlabel Component? Because redux has not yet been initialised

> NextJS hosted on Vercel with Firebase backend

This directory is isomorphic. You can use it anywhere. With minimum effort you can cut and paste it into a freshly bootstrapped Creat React App application, NextJS and more.

#### NPM package

@goldlabel/core
