'use client';
import { ContentShape } from './types';
import * as React from 'react';
import { Layout } from './Layout';
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  useGoldlabelDispatch,
  useGoldlabelSelect,
  selectContent,
  updateUser,
} from './AppState';
import { updateContent } from './AppState/actions/updateContent';

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

export const fb = initializeApp(firebaseConfig);

export default function Start(props: {
  children: React.ReactNode;
  content: ContentShape;
}) {
  const { children, content } = props;
  const dispatch = useGoldlabelDispatch();
  const startContent = useGoldlabelSelect(selectContent);

  React.useEffect(() => {
    if (!startContent) dispatch(updateContent(content));
  }, [dispatch, startContent, content]);

  React.useEffect(() => {
    const unsubscribe = getAuth().onAuthStateChanged((user) => {
      if (user) {
        dispatch(updateUser(user));
      } else {
        dispatch(updateUser(null));
      }
    });
    return () => unsubscribe();
  }, [dispatch]);

  return <Layout>{children}</Layout>;
}
