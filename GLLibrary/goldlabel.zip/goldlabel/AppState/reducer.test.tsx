import goldlabelReducer from './reducer';

describe('goldlabel reducer', () => {
  it('The sun should should always rise', () => {
    expect(true);
  });

  // const initialState: GoldlabelState = {
  //   score: 3,
  //   user: null,
  // };

  // it('should handle initial state', () => {
  //   expect(goldlabelReducer(undefined, { type: 'unknown' })).toEqual({
  //     score: 0,
  //     user: null,
  //   });
  // });
});
