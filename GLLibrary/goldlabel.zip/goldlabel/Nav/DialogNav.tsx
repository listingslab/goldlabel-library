import * as React from 'react';
import {
  ButtonBase,
  Typography,
  Box,
  CardHeader,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import IconClose from '@mui/icons-material/CloseOutlined';
import IconSave from '@mui/icons-material/SaveOutlined';
import {
  useGoldlabelDispatch,
  useGoldlabelSelect,
  selectNavDialogOpen,
  toggleNavDialogOpen,
  navigateTo,
} from '../AppState';
import { FixedNav } from '../Nav';
import { Icon } from '../Design';

export default function DialogNav() {
  const navDialogOpen = useGoldlabelSelect(selectNavDialogOpen);
  const dispatch = useGoldlabelDispatch();
  const closeNavDialog = () => {
    dispatch(toggleNavDialogOpen(false));
  };
  const canSave: boolean = false;
  return (
    <Dialog
      open={navDialogOpen || false}
      fullScreen={true}
      fullWidth
      maxWidth="xs"
      onClose={closeNavDialog}
    >
      <DialogTitle>
        <CardHeader
          avatar={
            <IconButton
              sx={{ ml: -1 }}
              onClick={() => {
                dispatch(navigateTo('/', '_self'));
                dispatch(toggleNavDialogOpen(false));
              }}
            >
              <Icon icon="goldlabel" color="primary" />
            </IconButton>
          }
          action={
            <IconButton onClick={() => dispatch(toggleNavDialogOpen(false))}>
              <IconClose color="primary" />
            </IconButton>
          }
        />
      </DialogTitle>
      <DialogContent>
        <FixedNav />
      </DialogContent>
      <DialogActions>
        <Box sx={{ flexGrow: 1 }} />
        {canSave ? (
          <ButtonBase
            id="goldlabel-auth-signin-btn"
            sx={{ borderRadius: 1, mr: 4 }}
            onClick={(e: React.MouseEvent) => {
              e.preventDefault();
              closeNavDialog();
              // console.log('Dispatch sign in action');
            }}
          >
            <Box sx={{ mr: 1, pr: 1 }}>
              <Typography variant="button" component="h3">
                Save & Close
              </Typography>
            </Box>
            <Box sx={{ ml: 1 }}>
              <IconSave color="primary" />
            </Box>
          </ButtonBase>
        ) : null}
      </DialogActions>
    </Dialog>
  );
}
