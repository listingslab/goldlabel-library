import * as React from 'react';
import {
  List,
  ListItemButton,
  ListItemText,
  ListItemIcon,
} from '@mui/material';
import { useGoldlabelDispatch, navigateTo } from '../AppState';
import { Icon } from '../Design';

export default function FixedNav() {
  const dispatch = useGoldlabelDispatch();

  const onItemClick = (path: string) => {
    dispatch(navigateTo(path, '_self'));
  };

  return (
    <>
      <List>
        <ListItemButton
          onClick={() => {
            onItemClick('/');
          }}
        >
          <ListItemIcon>
            <Icon icon="home" color="primary" />
          </ListItemIcon>
          <ListItemText primary="Home" />
        </ListItemButton>

        <ListItemButton
          onClick={() => {
            onItemClick('/you');
          }}
        >
          <ListItemIcon>
            <Icon icon="account" color="primary" />
          </ListItemIcon>
          <ListItemText primary="You" />
        </ListItemButton>
        <ListItemButton
          onClick={() => {
            onItemClick('/ai');
          }}
        >
          <ListItemIcon>
            <Icon icon="openai" color="primary" />
          </ListItemIcon>
          <ListItemText primary="A.I." />
        </ListItemButton>

        <ListItemButton
          onClick={() => {
            onItemClick('/wordpress');
          }}
        >
          <ListItemIcon>
            <Icon icon="wordpress" color="primary" />
          </ListItemIcon>
          <ListItemText primary="WordPress" />
        </ListItemButton>

        <ListItemButton
          onClick={() => {
            onItemClick('/wip');
          }}
        >
          <ListItemIcon>
            <Icon icon="work" color="primary" />
          </ListItemIcon>
          <ListItemText primary="W.I.P." />
        </ListItemButton>
      </List>
    </>
  );
}
